import HTMLTestRunner
class Yelidhtml():
    def __init__(self):
        pass
